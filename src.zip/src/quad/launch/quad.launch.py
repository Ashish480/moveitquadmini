import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    # Get the package directory
    pkg_share = get_package_share_directory('quad')
    
    # Set paths to URDF and RVIZ config files
    default_model_path = os.path.join(pkg_share, 'urdf/spotmicroai.urdf')
    default_rviz_config_path = os.path.join(pkg_share, 'rviz/urdf_viewer.rviz')
    
    # Create launch configuration variables
    model = LaunchConfiguration('model')
    rviz_config = LaunchConfiguration('rviz_config')
    
    # Declare launch arguments
    declare_model_path = DeclareLaunchArgument(
        name='model',
        default_value=default_model_path,
        description='Path to the robot URDF file'
    )
    
    declare_rviz_config = DeclareLaunchArgument(
        name='rviz_config',
        default_value=default_rviz_config_path,
        description='Path to the RViz config file'
    )
    
    # Create a robot state publisher node
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': open(default_model_path).read(),
                     'use_sim_time': False}]
    )
    
    # Create a joint state publisher node
    joint_state_publisher_gui = Node(
        package='joint_state_publisher_gui',
        executable='joint_state_publisher_gui',
        name='joint_state_publisher_gui',
        output='screen'
    )
    
    # Create an RViz node
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config]
    )
    
    # Return the launch description
    return LaunchDescription([
        declare_model_path,
        declare_rviz_config,
        robot_state_publisher,
        joint_state_publisher_gui,
        rviz
    ])
