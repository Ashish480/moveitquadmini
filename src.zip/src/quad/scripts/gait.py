#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
import time
from rclpy.duration import Duration

class JointStateController(Node):
    def __init__(self):
        super().__init__('joint_state_controller')
        
        # Create publisher for joint states
        self.joint_state_pub = self.create_publisher(
            JointState,
            '/joint_states',
            10)
            
        # Define the joint names for SpotMicro
        self.joint_names = [
            'motor_front_left_hip',
            'motor_front_left_upper_leg',
            'motor_front_left_lower_leg',
            'motor_front_right_hip',
            'motor_front_right_upper_leg',
            'motor_front_right_lower_leg',
            'motor_back_left_hip',
            'motor_back_left_upper_leg',
            'motor_back_left_lower_leg',
            'motor_back_right_hip',
            'motor_back_right_upper_leg',
            'motor_back_right_lower_leg'
        ]
        
        # Default standing position
        self.standing_pose = [0.0, 0.5, -1.0, 0.0, 0.5, -1.0, 0.0, 0.5, -1.0, 0.0, 0.5, -1.0]
        
        # Create timer for demonstration movement sequence
        self.timer = self.create_timer(1.0, self.timer_callback)
        self.movement_index = 0
        self.movements = [
            self.standing_pose,  # Standing
            [0.0, 0.2, -0.5, 0.0, 0.5, -1.0, 0.0, 0.5, -1.0, 0.0, 0.5, -1.0],  # Lift front left leg
            self.standing_pose.copy(),  # Back to standing
            [0.0, 0.5, -1.0, 0.0, 0.2, -0.5, 0.0, 0.5, -1.0, 0.0, 0.5, -1.0],  # Lift front right leg
            self.standing_pose.copy(),  # Back to standing
            [0.3, 0.5, -1.0, -0.3, 0.5, -1.0, 0.3, 0.5, -1.0, -0.3, 0.5, -1.0],  # Rotate left
            self.standing_pose.copy(),  # Back to standing
            [-0.3, 0.5, -1.0, 0.3, 0.5, -1.0, -0.3, 0.5, -1.0, 0.3, 0.5, -1.0],  # Rotate right
            self.standing_pose.copy(),  # Back to standing
            [0.0, 0.9, -1.8, 0.0, 0.9, -1.8, 0.0, 0.9, -1.8, 0.0, 0.9, -1.8],  # Sit
            self.standing_pose.copy()   # Back to standing
        ]
        
        self.get_logger().info('Joint State Controller started. Running demo sequence...')
        
    def send_joint_state(self, positions):
        """Send a joint state message with the given positions"""
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = self.joint_names
        msg.position = positions
        msg.velocity = [0.0] * len(positions)  # No velocity
        msg.effort = [0.0] * len(positions)    # No effort
        
        self.joint_state_pub.publish(msg)
        
    def timer_callback(self):
        """Cycle through pre-defined movements"""
        positions = self.movements[self.movement_index]
        self.get_logger().info(f'Moving to position {self.movement_index}')
        self.send_joint_state(positions)
        
        # Move to next position in sequence
        self.movement_index = (self.movement_index + 1) % len(self.movements)

    def move_to_pose(self, pose, duration_sec=1.0):
        """Smoothly move to a target pose over the specified duration"""
        start_pose = self.standing_pose.copy()  # Assuming we start from standing
        start_time = self.get_clock().now()
        end_time = start_time + Duration(seconds=duration_sec)
        
        rate = self.create_rate(50)  # 50 Hz update rate
        
        while self.get_clock().now() < end_time:
            # Calculate interpolation factor (0 to 1)
            elapsed = (self.get_clock().now() - start_time).nanoseconds / 1e9
            t = min(elapsed / duration_sec, 1.0)
            
            # Linear interpolation between start and target poses
            current_pose = [start_pose[i] + t * (pose[i] - start_pose[i]) for i in range(len(pose))]
            self.send_joint_state(current_pose)
            
            rate.sleep()
        
        # Ensure we end exactly at the target pose
        self.send_joint_state(pose)

    def rotate_robot(self, angle_deg):
        """Rotate the robot by the specified angle in degrees"""
        # Convert to radians
        angle_rad = angle_deg * 3.14159 / 180.0
        
        # Scale for hip joints (adjust as needed)
        hip_angle = min(max(angle_rad * 0.5, -0.5), 0.5)
        
        # Create a pose with rotated hip joints
        rotation_pose = self.standing_pose.copy()
        rotation_pose[0] = hip_angle    # Front left hip
        rotation_pose[3] = -hip_angle   # Front right hip
        rotation_pose[6] = hip_angle    # Back left hip
        rotation_pose[9] = -hip_angle   # Back right hip
        
        # Move to this pose smoothly
        self.move_to_pose(rotation_pose)
        
        # Then back to standing
        time.sleep(1.0)
        self.move_to_pose(self.standing_pose)

def main(args=None):
    rclpy.init(args=args)
    controller = JointStateController()
    
    # You can uncomment these for manual control instead of the timer
    # controller.timer.cancel()  # Cancel automated sequence
    # controller.get_logger().info('Manual control activated')
    # controller.move_to_pose(controller.standing_pose)  # Start in standing position
    # time.sleep(2)
    # controller.rotate_robot(30)  # Rotate 30 degrees
    
    try:
        rclpy.spin(controller)
    except KeyboardInterrupt:
        pass
    
    controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
