#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import sys
import tty
import termios
import select
import threading

class KeyboardController(Node):
    def __init__(self):
        super().__init__('keyboard_controller')
        self.publisher = self.create_publisher(String, '/keyboard_commands', 10)
        self.key_thread = threading.Thread(target=self.get_key)
        self.key_thread.daemon = True
        self.key_thread.start()
        self.get_logger().info('Keyboard controller started. Press w to rotate the robot 30 degrees.')
        
    def get_key(self):
        # Save terminal settings
        old_settings = termios.tcgetattr(sys.stdin)
        try:
            # Set terminal to raw mode
            tty.setcbreak(sys.stdin.fileno())
            
            while rclpy.ok():
                # Check if input is available
                if select.select([sys.stdin], [], [], 0)[0] == [sys.stdin]:
                    key = sys.stdin.read(1)
                    
                    # Exit on Ctrl+C
                    if key == '\x03':
                        break
                    
                    msg = String()
                    msg.data = key
                    self.publisher.publish(msg)
                    self.get_logger().info(f'Published key: {key}')
        finally:
            # Restore terminal settings
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)

def main(args=None):
    rclpy.init(args=args)
    keyboard_controller = KeyboardController()
    rclpy.spin(keyboard_controller)
    keyboard_controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
