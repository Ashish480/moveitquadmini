#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState, Imu
from std_msgs.msg import Header

import pybullet as p
import pybullet_data
import time
import numpy as np
import os
import tempfile
from threading import Thread, Lock, Event

class SpotMicroPyBulletROS2Bridge(Node):
    def __init__(self):
        super().__init__('spotmicro_pybullet_bridge')
        
        # Thread synchronization objects
        self.simulation_lock = Lock()
        self.shutdown_event = Event()
        
        # Create publisher for joint states and IMU data
        self.joint_state_publisher = self.create_publisher(
            JointState,
            'joint_states',
            10
        )
        
        # IMU publisher
        self.imu_publisher = self.create_publisher(
            Imu,
            'imu/data',
            10
        )
        
        # Initialize PyBullet with better simulation parameters
        try:
            self.physics_client = p.connect(p.GUI)
            p.configureDebugVisualizer(p.COV_ENABLE_GUI, 1)  # Enable GUI for controls
            p.resetDebugVisualizerCamera(
                cameraDistance=0.6,
                cameraYaw=0,
                cameraPitch=-20,
                cameraTargetPosition=[0, 0, 0]
            )
            
            # Create GUI controls
            self.create_gui_controls()
            
            p.setAdditionalSearchPath(pybullet_data.getDataPath())
            
            # Modified physics parameters for smoother behavior
            p.setPhysicsEngineParameter(
                fixedTimeStep=1.0/240.0, 
                numSolverIterations=5,     # Further reduced for even less stiffness
                numSubSteps=8
            )
            p.setGravity(0, 0, -9.81)  # Standard gravity
        except Exception as e:
            self.get_logger().error(f"Failed to initialize PyBullet: {e}")
            raise
        
        # Load ground with higher friction
        try:
            ground_id = p.loadURDF("plane.urdf")
            p.changeDynamics(
                ground_id, -1, 
                lateralFriction=0.8,
                rollingFriction=0.1,
                spinningFriction=0.1
            )
        except Exception as e:
            self.get_logger().error(f"Failed to load ground plane: {e}")
            self.cleanup()
            raise
        
        # Get the path to the SpotMicroAI URDF file
        self.urdf_path = os.path.join(
            os.path.expanduser('~'),
            'review_ws/src/quad/urdf/spotmicroai.urdf'
        )
        
        # Check if the URDF file exists, if not create a temporary one
        if not os.path.exists(self.urdf_path):
            self.get_logger().warn(f"URDF file not found at {self.urdf_path}")
            self.get_logger().info("Creating temporary URDF file...")
            
            # Write the URDF content to a temporary file
            try:
                with tempfile.NamedTemporaryFile(suffix='.urdf', delete=False) as f:
                    urdf_content = self.get_urdf_content()
                    f.write(urdf_content.encode('utf-8'))
                    self.urdf_path = f.name
                    self.get_logger().info(f"Created temporary URDF file at {self.urdf_path}")
            except Exception as e:
                self.get_logger().error(f"Failed to create temporary URDF file: {e}")
                self.cleanup()
                raise
        
        # Record the spawn time for the 4-second delay
        self.spawn_time = time.time()
        
        # CRUCIAL CHANGE: Load robot with useFixedBase=True initially to prevent "flying around"
        # We'll switch this to False after initialization
        start_pos = [0, 0, 0.25]  # Start slightly above ground
        start_orientation = p.getQuaternionFromEuler([0, 0, 0])
        
        try:
            self.robot_id = p.loadURDF(
                self.urdf_path, 
                start_pos, 
                start_orientation,
                useFixedBase=True,  # Start with fixed base for stability!
                flags=p.URDF_USE_SELF_COLLISION
            )
            
            if self.robot_id < 0:
                self.get_logger().error("Failed to load URDF!")
                self.cleanup()
                return
                
            self.get_logger().info(f"Robot loaded with ID: {self.robot_id}")
            self.get_logger().info(f"Robot base is FIXED during initialization")
            self.get_logger().info(f"Waiting 4 seconds before starting any movement...")
            
            # Improve dynamic properties of the robot base
            p.changeDynamics(
                self.robot_id, 
                -1,  # Base link
                linearDamping=0.05,
                angularDamping=0.05
            )
        except Exception as e:
            self.get_logger().error(f"Failed to load robot model: {e}")
            self.cleanup()
            raise
        
        # Get joint information
        try:
            self.num_joints = p.getNumJoints(self.robot_id)
            self.get_logger().info(f"Number of joints: {self.num_joints}")
            
            # Map for the actuated joints to match the ROS joint names
            self.joint_map = {
                # Legs (hip joints)
                'front_left_leg': -1,
                'front_right_leg': -1,
                'rear_left_leg': -1,
                'rear_right_leg': -1,
                
                # Feet (knee joints)
                'front_left_foot': -1,
                'front_right_foot': -1,
                'rear_left_foot': -1,
                'rear_right_foot': -1
            }
            
            # Get joint indices
            for i in range(self.num_joints):
                joint_info = p.getJointInfo(self.robot_id, i)
                joint_name = joint_info[1].decode('utf-8')
                joint_type = joint_info[2]
                
                self.get_logger().info(f"Joint {i}: {joint_name} (Type: {joint_type})")
                
                if joint_name in self.joint_map:
                    self.joint_map[joint_name] = i
                    # Very reduced damping and friction for initial setup
                    p.changeDynamics(
                        self.robot_id, 
                        i, 
                        lateralFriction=0.5,
                        jointDamping=0.01,     # Minimal damping
                        maxJointVelocity=5.0,  # Lower max velocity for safety
                    )
                    
            # Verify all joint indices were found
            missing_joints = [name for name, idx in self.joint_map.items() if idx == -1]
            if missing_joints:
                self.get_logger().warn(f"Could not find these joints: {missing_joints}")
        except Exception as e:
            self.get_logger().error(f"Failed during joint initialization: {e}")
            self.cleanup()
            raise
        
        # Create ordered lists of joints for convenience
        # This order must match the joint order in your gait algorithm
        self.ros_joint_names = [
            'front_left_leg', 'front_left_foot',
            'front_right_leg', 'front_right_foot',
            'rear_left_leg', 'rear_left_foot',
            'rear_right_leg', 'rear_right_foot'
        ]
        
        self.leg_joints = [self.joint_map[name] for name in self.ros_joint_names if self.joint_map[name] != -1]
        
        # Setup IMU parameters
        self.imu_link_index = -1  # Base link of the robot
        self.imu_noise_std = 0.01  # Standard deviation of IMU noise
        self.imu_data = {
            'orientation': [0, 0, 0, 1],  # Quaternion (x, y, z, w)
            'angular_velocity': [0, 0, 0],  # rad/s
            'linear_acceleration': [0, 0, 0]  # m/s^2
        }
        
        # Significantly reduced PID gains for even gentler stabilization
        self.pid = {
            'roll': {'p': 0.2, 'i': 0.02, 'd': 0.05, 'error_sum': 0, 'last_error': 0},
            'pitch': {'p': 0.2, 'i': 0.02, 'd': 0.05, 'error_sum': 0, 'last_error': 0}
        }
        self.target_orientation = {'roll': 0.0, 'pitch': 0.0}  # Target is level
        self.max_correction = 0.08  # Maximum correction angle in radians (further reduced)
        
        # Create timers
        self.sim_timer = self.create_timer(1.0/240.0, self.simulation_step)
        self.pub_timer = self.create_timer(1.0/30.0, self.publish_joint_states)
        self.imu_timer = self.create_timer(1.0/100.0, self.update_imu)  # 100Hz IMU updates
        self.gui_timer = self.create_timer(0.05, self.check_gui_events)  # 20Hz GUI check
        
        # Set up demo state
        self.simulation_running = True
        self.simulation_thread = None
        self.current_joint_angles = [0.0] * len(self.leg_joints)  # Current commanded angles
        self.stabilization_enabled = True  # Enable IMU stabilization
        self.initialization_done = False  # Flag to track initialization state
        
        # Important for smooth movement
        self.target_joint_angles = [0.0] * len(self.leg_joints)
        self.smoothing_factor = 0.05  # Very gentle smoothing (reduced from 0.1)
        
        # Control command variables
        self.command_sit = False
        self.command_stand = False
        self.command_trot = False
        self.currently_sitting = False
        self.currently_standing = False
        self.currently_trotting = False
        
        # Start with a short settling period to ensure stability
        self.initialize_robot_pose()
        
        # Flag to track when the base should be unfixed
        self.base_fixed = True
        self.initialization_complete = False
        
        # For GUI status display
        self.status_text_id = None
        
        self.get_logger().info("SpotMicro PyBullet-ROS2 Bridge initialized with IMU stabilization!")
    
    def create_gui_controls(self):
        """Create GUI buttons for controlling the robot"""
        # Create a parameter panel
        p.configureDebugVisualizer(p.COV_ENABLE_GUI, 1)
        
        # Create buttons
        self.button_sit = p.addUserDebugParameter("Sit", 1, 0, 0)  # Button
        self.button_stand = p.addUserDebugParameter("Stand", 1, 0, 0)  # Button
        self.button_trot = p.addUserDebugParameter("Trot", 1, 0, 0)  # Button
        self.button_stop = p.addUserDebugParameter("Stop Movement", 1, 0, 0)  # Button
        self.button_toggle_stabilization = p.addUserDebugParameter("Toggle Stabilization", 1, 0, 0)  # Button
        
        # Initial values for tracking button state
        self.last_sit_value = p.readUserDebugParameter(self.button_sit)
        self.last_stand_value = p.readUserDebugParameter(self.button_stand)
        self.last_trot_value = p.readUserDebugParameter(self.button_trot)
        self.last_stop_value = p.readUserDebugParameter(self.button_stop)
        self.last_toggle_value = p.readUserDebugParameter(self.button_toggle_stabilization)

        # Add status text
        self.status_text_id = p.addUserDebugText(
            "Status: Initializing...",
            [0, 0, 0.5],
            textColorRGB=[1, 1, 0],
            textSize=1.5
        )
        
    def check_gui_events(self):
        """Check if GUI buttons have been pressed"""
        if self.shutdown_event.is_set() or not self.simulation_running:
            return
            
        try:
            with self.simulation_lock:
                if not self.is_connected():
                    return
                    
                if not self.initialization_complete:
                    if time.time() - self.spawn_time >= 4.0 and not self.base_fixed:
                        self.initialization_complete = True
                        if self.status_text_id is not None:
                            p.removeUserDebugItem(self.status_text_id)
                        self.status_text_id = p.addUserDebugText(
                            "Status: Ready - Select Command",
                            [0, 0, 0.5],
                            textColorRGB=[0, 1, 0],
                            textSize=1.5
                        )
                    elif time.time() - self.spawn_time < 4.0:
                        remaining = 4.0 - (time.time() - self.spawn_time)
                        if self.status_text_id is not None:
                            p.removeUserDebugItem(self.status_text_id)
                        self.status_text_id = p.addUserDebugText(
                            f"Status: Initializing... {remaining:.1f}s",
                            [0, 0, 0.5],
                            textColorRGB=[1, 1, 0],
                            textSize=1.5
                        )
                    return
                    
                # Check sit button
                new_sit_value = p.readUserDebugParameter(self.button_sit)
                if new_sit_value != self.last_sit_value:
                    self.last_sit_value = new_sit_value
                    if not self.currently_sitting:
                        self.get_logger().info("GUI Command: SIT")
                        self.command_sit = True
                        # Stop other actions
                        self.command_stand = False
                        self.command_trot = False
                        # Update status
                        if self.status_text_id is not None:
                            p.removeUserDebugItem(self.status_text_id)
                        self.status_text_id = p.addUserDebugText(
                            "Status: Sitting...",
                            [0, 0, 0.5],
                            textColorRGB=[0, 0.7, 1],
                            textSize=1.5
                        )
                
                # Check stand button
                new_stand_value = p.readUserDebugParameter(self.button_stand)
                if new_stand_value != self.last_stand_value:
                    self.last_stand_value = new_stand_value
                    if not self.currently_standing:
                        self.get_logger().info("GUI Command: STAND")
                        self.command_stand = True
                        # Stop other actions
                        self.command_sit = False
                        self.command_trot = False
                        # Update status
                        if self.status_text_id is not None:
                            p.removeUserDebugItem(self.status_text_id)
                        self.status_text_id = p.addUserDebugText(
                            "Status: Standing...",
                            [0, 0, 0.5],
                            textColorRGB=[0, 1, 0.5],
                            textSize=1.5
                        )
                
                # Check trot button
                new_trot_value = p.readUserDebugParameter(self.button_trot)
                if new_trot_value != self.last_trot_value:
                    self.last_trot_value = new_trot_value
                    if not self.currently_trotting:
                        self.get_logger().info("GUI Command: TROT")
                        self.command_trot = True
                        # Stop other actions
                        self.command_sit = False
                        self.command_stand = False
                        # Update status
                        if self.status_text_id is not None:
                            p.removeUserDebugItem(self.status_text_id)
                        self.status_text_id = p.addUserDebugText(
                            "Status: Trotting...",
                            [0, 0, 0.5],
                            textColorRGB=[0.7, 0.7, 1],
                            textSize=1.5
                        )
                
                # Check stop button
                new_stop_value = p.readUserDebugParameter(self.button_stop)
                if new_stop_value != self.last_stop_value:
                    self.last_stop_value = new_stop_value
                    self.get_logger().info("GUI Command: STOP")
                    # Stop all actions
                    self.command_sit = False
                    self.command_stand = False
                    self.command_trot = False
                    self.currently_sitting = False
                    self.currently_standing = False
                    self.currently_trotting = False
                    # Update status
                    if self.status_text_id is not None:
                        p.removeUserDebugItem(self.status_text_id)
                    self.status_text_id = p.addUserDebugText(
                        "Status: Stopped - Select Command",
                        [0, 0, 0.5],
                        textColorRGB=[1, 0.5, 0],
                        textSize=1.5
                    )
                
                # Check stabilization toggle button
                new_toggle_value = p.readUserDebugParameter(self.button_toggle_stabilization)
                if new_toggle_value != self.last_toggle_value:
                    self.last_toggle_value = new_toggle_value
                    self.stabilization_enabled = not self.stabilization_enabled
                    stab_status = "ENABLED" if self.stabilization_enabled else "DISABLED"
                    self.get_logger().info(f"GUI Command: TOGGLE STABILIZATION - Now {stab_status}")
        except Exception as e:
            self.get_logger().warn(f"Error in GUI event handler: {e}")
    
    def initialize_robot_pose(self):
        """Initialize the robot to a stable position immediately"""
        if self.shutdown_event.is_set():
            return
            
        try:
            with self.simulation_lock:
                if not self.is_connected():
                    return
                    
                self.get_logger().info("Initializing stable robot pose (with fixed base)...")
                
                # First reset all joints to zero using resetJointState for immediate effect
                for i in self.leg_joints:
                    p.resetJointState(self.robot_id, i, 0.0)
                
                # Let it settle briefly
                for _ in range(20):
                    p.stepSimulation()
                
                # Then set to initial crouched position for stability - very slowly
                # Set a lower crouch position that places feet on the ground
                crouch_positions = [
                    0.0, -0.8,  # Front Left: leg, foot (reduced bend from -0.9)
                    0.0, -0.8,  # Front Right: leg, foot
                    0.0, -0.8,  # Rear Left: leg, foot
                    0.0, -0.8   # Rear Right: leg, foot
                ]
                
                # Reset joint states directly for immediate effect, but with gentle velocity
                for i, joint_index in enumerate(self.leg_joints):
                    p.resetJointState(self.robot_id, joint_index, crouch_positions[i], targetVelocity=0.0)
                    
                # Store current joint angles
                self.current_joint_angles = crouch_positions.copy()
                self.target_joint_angles = crouch_positions.copy()
                
                # Let it settle for a moment with fixed base
                for _ in range(100):
                    p.stepSimulation()
                
                self.get_logger().info("Robot initialized in stable crouched pose")
        except Exception as e:
            self.get_logger().error(f"Error in initialize_robot_pose: {e}")
    
    def update_imu(self):
        """Update IMU data from PyBullet simulation"""
        if self.shutdown_event.is_set() or not self.simulation_running:
            return
            
        try:
            with self.simulation_lock:
                if not self.is_connected():
                    return
                    
                # Get position and orientation of the robot base
                pos, orn = p.getBasePositionAndOrientation(self.robot_id)
                
                # Get linear velocity and angular velocity
                lin_vel, ang_vel = p.getBaseVelocity(self.robot_id)
                
                # Add some noise to make it more realistic
                orn_noise = np.random.normal(0, self.imu_noise_std, 4)
                ang_vel_noise = np.random.normal(0, self.imu_noise_std, 3)
                
                # Apply noise
                noisy_orn = [o + n for o, n in zip(orn, orn_noise)]
                noisy_ang_vel = [a + n for a, n in zip(ang_vel, ang_vel_noise)]
                
                # Normalize quaternion after adding noise
                orn_magnitude = np.sqrt(sum([o*o for o in noisy_orn]))
                noisy_orn = [o / orn_magnitude for o in noisy_orn]
                
                # Calculate linear acceleration (including gravity)
                # For simplicity, we'll use gravity vector transformed by orientation
                gravity = [0, 0, -9.81]
                rot_matrix = p.getMatrixFromQuaternion(orn)
                local_gravity = [
                    gravity[0] * rot_matrix[0] + gravity[1] * rot_matrix[3] + gravity[2] * rot_matrix[6],
                    gravity[0] * rot_matrix[1] + gravity[1] * rot_matrix[4] + gravity[2] * rot_matrix[7],
                    gravity[0] * rot_matrix[2] + gravity[1] * rot_matrix[5] + gravity[2] * rot_matrix[8]
                ]
                
                # Store IMU data
                self.imu_data = {
                    'orientation': noisy_orn,
                    'angular_velocity': noisy_ang_vel,
                    'linear_acceleration': local_gravity
                }
                
                # Publish IMU data
                self.publish_imu()
                
                # Apply stabilization if enabled and the base is not fixed
                if self.stabilization_enabled and not self.base_fixed:
                    self.apply_imu_stabilization()
        except Exception as e:
            if "Not connected" not in str(e):  # Ignore disconnect errors during shutdown
                self.get_logger().debug(f"Error in update_imu: {e}")
    
    def publish_imu(self):
        """Publish IMU data to ROS"""
        if self.shutdown_event.is_set():
            return
            
        imu_msg = Imu()
        imu_msg.header = Header()
        imu_msg.header.stamp = self.get_clock().now().to_msg()
        imu_msg.header.frame_id = "base_link"
        
        # Orientation (quaternion)
        imu_msg.orientation.x = self.imu_data['orientation'][0]
        imu_msg.orientation.y = self.imu_data['orientation'][1]
        imu_msg.orientation.z = self.imu_data['orientation'][2]
        imu_msg.orientation.w = self.imu_data['orientation'][3]
        
        # Angular velocity (rad/s)
        imu_msg.angular_velocity.x = self.imu_data['angular_velocity'][0]
        imu_msg.angular_velocity.y = self.imu_data['angular_velocity'][1]
        imu_msg.angular_velocity.z = self.imu_data['angular_velocity'][2]
        
        # Linear acceleration (m/s^2)
        imu_msg.linear_acceleration.x = self.imu_data['linear_acceleration'][0]
        imu_msg.linear_acceleration.y = self.imu_data['linear_acceleration'][1]
        imu_msg.linear_acceleration.z = self.imu_data['linear_acceleration'][2]
        
        # Publish
        self.imu_publisher.publish(imu_msg)
    
    def apply_imu_stabilization(self):
        """Apply stabilization based on IMU feedback using PID controller"""
        if self.shutdown_event.is_set() or not self.is_connected():
            return
            
        # Get roll and pitch from quaternion
        roll, pitch, _ = p.getEulerFromQuaternion(self.imu_data['orientation'])
        
        # Increased threshold for applying corrections
        if abs(roll) > 0.1 or abs(pitch) > 0.1:  # Only stabilize if tilt is significant
            # Calculate PID corrections for roll and pitch
            roll_correction = self.calculate_pid_correction('roll', roll)
            pitch_correction = self.calculate_pid_correction('pitch', pitch)
            self.apply_stabilization_corrections(roll_correction, pitch_correction)
    
    def calculate_pid_correction(self, axis, current_value):
        """Calculate PID correction for given axis"""
        # Calculate error
        error = self.target_orientation[axis] - current_value
        
        # Proportional term
        p_term = self.pid[axis]['p'] * error
        
        # Integral term with anti-windup
        self.pid[axis]['error_sum'] += error
        self.pid[axis]['error_sum'] = max(min(self.pid[axis]['error_sum'], 3), -3)  # Reduced anti-windup limit
        i_term = self.pid[axis]['i'] * self.pid[axis]['error_sum']
        
        # Derivative term
        d_term = self.pid[axis]['d'] * (error - self.pid[axis]['last_error'])
        self.pid[axis]['last_error'] = error
        
        # Calculate total correction
        correction = p_term + i_term + d_term
        
        # Limit correction
        correction = max(min(correction, self.max_correction), -self.max_correction)
        
        return correction
    
    def apply_stabilization_corrections(self, roll_correction, pitch_correction):
        """Apply roll and pitch corrections to leg joints"""
        if self.shutdown_event.is_set() or not self.is_connected():
            return
            
        # We need to modify the current commanded angles based on the corrections
        
        # Roll correction affects left and right legs differently
        if roll_correction != 0:
            # Positive roll means robot is tilting right, need to extend left legs and retract right legs
            # Left legs (Front Left and Rear Left)
            self.target_joint_angles[1] = min(self.target_joint_angles[1] + roll_correction, -0.5)  # FL foot
            self.target_joint_angles[5] = min(self.target_joint_angles[5] + roll_correction, -0.5)  # RL foot
            
            # Right legs (Front Right and Rear Right)
            self.target_joint_angles[3] = max(self.target_joint_angles[3] - roll_correction, -1.1)  # FR foot
            self.target_joint_angles[7] = max(self.target_joint_angles[7] - roll_correction, -1.1)  # RR foot
            
        # Pitch correction affects front and rear legs differently
        if pitch_correction != 0:
            # Positive pitch means robot is tilting forward, need to extend front legs and retract rear legs
            # Front legs
            self.target_joint_angles[1] = min(self.target_joint_angles[1] + pitch_correction, -0.5)  # FL foot
            self.target_joint_angles[3] = min(self.target_joint_angles[3] + pitch_correction, -0.5)  # FR foot
            
            # Rear legs
            self.target_joint_angles[5] = max(self.target_joint_angles[5] - pitch_correction, -1.1)  # RL foot
            self.target_joint_angles[7] = max(self.target_joint_angles[7] - pitch_correction, -1.1)  # RR foot
        
        # Apply the stabilized joint positions through smooth interpolation
        self.smooth_set_joint_angles(self.target_joint_angles)
    
    def get_urdf_content(self):
        """Return the URDF content as a string"""
        return """<?xml version="1.0" encoding="utf-8"?>
<!-- =================================================================================== -->
<!-- |    This document was autogenerated by xacro from spotmicroai.urdf.xacro         | -->
<!-- |    EDITING THIS FILE BY HAND IS NOT RECOMMENDED                                 | -->
<!-- =================================================================================== -->
<robot name="SpotMicroAI">
  <material name="yellow">
    <color rgba="0.92 0.83 0.0 1"/>
  </material>
  <material name="black">
    <color rgba="0.1 0.1 0.1 1"/>
  </material>
  <material name="grey">
    <color rgba="0.6 0.6 0.6 1"/>
  </material>
  <!-- Robot Body -->
  <link name="base_link"/>
  <link name="base_inertia">
    <visual>
      <geometry>
        <box size="0.14 0.11 0.07"/>
      </geometry>
      <material name="black"/>
      <origin rpy="0 0 3.1416" xyz="0.0425 0.055 -0.02"/>
    </visual>
    <collision>
      <geometry>
        <box size="0.14 0.11 0.07"/>
      </geometry>
      <origin rpy="0 0 3.1416" xyz="0 0 0"/>
    </collision>
    <inertial>
      <mass value="2.80"/>
      <inertia ixx="100" ixy="0" ixz="0" iyy="100" iyz="0" izz="100"/>
    </inertial>
  </link>
  <joint name="base_inertia_joint" type="fixed">
    <parent link="base_link"/>
    <child link="base_inertia"/>
  </joint>
  <!-- Rest of URDF content follows... -->
</robot>
"""

    def is_connected(self):
        """Check if PyBullet is still connected"""
        try:
            # A simple function call that should work if connected
            p.getAPIVersion()
            return True
        except:
            return False

    def simulation_step(self):
        """Execute a single step of PyBullet simulation"""
        if self.shutdown_event.is_set() or not self.simulation_running:
            return

        try:
            with self.simulation_lock:
                if not self.is_connected():
                    return
                    
                p.stepSimulation()

                # Process GUI commands if initialization is complete
                if self.initialization_complete:
                    self.process_gui_commands()
        except Exception as e:
            if "Not connected" not in str(e):  # Ignore disconnect errors during shutdown
                self.get_logger().debug(f"Error in simulation_step: {e}")
            
    def process_gui_commands(self):
        """Process any pending commands from GUI buttons"""
        if self.shutdown_event.is_set():
            return
            
        # Check for sit command
        if self.command_sit and not self.currently_sitting:
            thread = Thread(target=self.execute_sit_command)
            thread.daemon = True
            thread.start()
            self.command_sit = False
            
        # Check for stand command
        elif self.command_stand and not self.currently_standing:
            thread = Thread(target=self.execute_stand_command)
            thread.daemon = True
            thread.start()
            self.command_stand = False
            
        # Check for trot command
        elif self.command_trot and not self.currently_trotting:
            thread = Thread(target=self.execute_trot_command)
            thread.daemon = True
            thread.start()
            self.command_trot = False
    
    def execute_sit_command(self):
        """Execute the sit command in a separate thread"""
        if self.shutdown_event.is_set():
            return
            
        self.currently_sitting = True
        self.currently_standing = False
        self.currently_trotting = False
        
        # Call the crouch position method
        self.crouch_position()
        
        # Only update status if we're still running
        if not self.shutdown_event.is_set() and self.simulation_running:
            try:
                with self.simulation_lock:
                    if self.is_connected() and self.status_text_id is not None:
                        p.removeUserDebugItem(self.status_text_id)
                        self.status_text_id = p.addUserDebugText(
                            "Status: Sitting (Idle)",
                            [0, 0, 0.5],
                            textColorRGB=[0, 0.7, 1],
                            textSize=1.5
                        )
            except Exception as e:
                self.get_logger().debug(f"Error updating status text: {e}")
    
    def execute_stand_command(self):
        """Execute the stand command in a separate thread"""
        if self.shutdown_event.is_set():
            return
            
        self.currently_sitting = False
        self.currently_standing = True
        self.currently_trotting = False
        
        # Call the stand position method
        self.stand_position()
        
        # Only update status if we're still running
        if not self.shutdown_event.is_set() and self.simulation_running:
            try:
                with self.simulation_lock:
                    if self.is_connected() and self.status_text_id is not None:
                        p.removeUserDebugItem(self.status_text_id)
                        self.status_text_id = p.addUserDebugText(
                            "Status: Standing (Idle)",
                            [0, 0, 0.5],
                            textColorRGB=[0, 1, 0.5],
                            textSize=1.5
                        )
            except Exception as e:
                self.get_logger().debug(f"Error updating status text: {e}")
    
    def execute_trot_command(self):
        """Execute the trot command in a separate thread"""
        if self.shutdown_event.is_set():
            return
            
        self.currently_sitting = False
        self.currently_standing = False
        self.currently_trotting = True
        
        # Before trotting, ensure the robot is standing
        if not self.stand_position():
            self.currently_trotting = False
            return
            
        # Call the trot gait with limited duration for safety (20 steps)
        self.trot_gait(continuous=False, max_steps=20)
        
        # Only update status if we're still running
        if not self.shutdown_event.is_set() and self.simulation_running:
            self.currently_trotting = False
            try:
                with self.simulation_lock:
                    if self.is_connected() and self.status_text_id is not None:
                        p.removeUserDebugItem(self.status_text_id)
                        self.status_text_id = p.addUserDebugText(
                            "Status: Trot Complete - Select Command",
                            [0, 0, 0.5],
                            textColorRGB=[0.7, 0.7, 1],
                            textSize=1.5
                        )
            except Exception as e:
                self.get_logger().debug(f"Error updating status text: {e}")
            
    def publish_joint_states(self):
        """Publish joint states to ROS"""
        if self.shutdown_event.is_set() or not self.simulation_running:
            return
            
        try:
            with self.simulation_lock:
                if not self.is_connected():
                    return
                    
                # Create JointState message
                joint_state_msg = JointState()
                joint_state_msg.header = Header()
                joint_state_msg.header.stamp = self.get_clock().now().to_msg()
                joint_state_msg.name = self.ros_joint_names
                
                # Get joint states from PyBullet
                positions = []
                velocities = []
                efforts = []
                
                for joint_idx in self.leg_joints:
                    # Get joint state from PyBullet
                    joint_state = p.getJointState(self.robot_id, joint_idx)
                    positions.append(joint_state[0])  # Position
                    velocities.append(joint_state[1])  # Velocity
                    efforts.append(joint_state[3])  # Applied Torque
                    
                joint_state_msg.position = positions
                joint_state_msg.velocity = velocities
                joint_state_msg.effort = efforts
                
                # Publish
                self.joint_state_publisher.publish(joint_state_msg)
        except Exception as e:
            if "Not connected" not in str(e) and "getJointState failed" not in str(e):
                self.get_logger().debug(f"Error in publish_joint_states: {e}")
        
    def set_joint_angles(self, angles):
        """Set angles for all joints with improved force and control"""
        if self.shutdown_event.is_set() or not self.is_connected():
            return False
            
        if len(angles) != len(self.leg_joints):
            self.get_logger().error(f"Expected {len(self.leg_joints)} joint angles, got {len(angles)}")
            return False
            
        # Update target joint angles
        self.target_joint_angles = angles.copy()
        
        # Smooth transition to new angles
        self.smooth_set_joint_angles(angles)
        return True
        
    def smooth_set_joint_angles(self, target_angles):
        """Smoothly interpolate between current and target angles"""
        if self.shutdown_event.is_set() or not self.is_connected():
            return
            
        try:
            with self.simulation_lock:
                # Update current joint angles toward target with smoothing factor
                for i in range(len(self.leg_joints)):
                    diff = target_angles[i] - self.current_joint_angles[i]
                    self.current_joint_angles[i] += diff * self.smoothing_factor
                    
                # Extremely reduced force and optimized gains for smoother motion
                for i, joint_index in enumerate(self.leg_joints):
                    p.setJointMotorControl2(
                        bodyUniqueId=self.robot_id,
                        jointIndex=joint_index,
                        controlMode=p.POSITION_CONTROL,
                        targetPosition=self.current_joint_angles[i],
                        # Very reduced force for incredibly gentle movement
                        force=50,  # Further reduced from 80 to 50
                        # Lower gains for smoother movement
                        positionGain=0.2,  # Further reduced from 0.3
                        velocityGain=0.3   # Further reduced from 0.5
                    )
        except Exception as e:
            if "Not connected" not in str(e):
                self.get_logger().debug(f"Error in smooth_set_joint_angles: {e}")
            
    def neutral_position(self):
        """Set robot to neutral position (all joints at 0)"""
        # Check if 4 seconds have passed since spawn
        if self.shutdown_event.is_set() or not self.is_connected():
            return False
            
        if time.time() - self.spawn_time < 4.0:
            self.get_logger().info(f"Waiting for 4-second initialization period... ({time.time() - self.spawn_time:.1f}s)")
            return False
            
        self.get_logger().info('Moving to neutral position')
        neutral = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        if not self.set_joint_angles(neutral):
            return False
        self.pause_simulation(2.0)  # Longer pause for gentler movement
        return True
        
    def crouch_position(self):
        """Move the robot to a crouched position with improved stability and gentler movement"""
        # Check if 4 seconds have passed since spawn
        if self.shutdown_event.is_set() or not self.is_connected():
            return False
            
        if time.time() - self.spawn_time < 4.0:
            self.get_logger().info(f"Waiting for 4-second initialization period... ({time.time() - self.spawn_time:.1f}s)")
            return False
            
        # Check if we need to unfix the base
        if self.base_fixed:
            try:
                with self.simulation_lock:
                    if not self.is_connected():
                        return False
                        
                    self.get_logger().info('Robot initial setup complete. Switching to movable base...')
                    # Create a temporary instance of the robot with unfixed base
                    pos, orn = p.getBasePositionAndOrientation(self.robot_id)
                    current_joint_positions = []
                    current_joint_velocities = []
                    
                    # Save all current joint states
                    for i in self.leg_joints:
                        joint_state = p.getJointState(self.robot_id, i)
                        current_joint_positions.append(joint_state[0])
                        current_joint_velocities.append(joint_state[1])
                    
                    # Remove the old robot
                    p.removeBody(self.robot_id)
                    
                    # Create a new one with the same position but unfixed base
                    self.robot_id = p.loadURDF(
                        self.urdf_path, 
                        pos, 
                        orn,
                        useFixedBase=False,  # Now use a movable base
                        flags=p.URDF_USE_SELF_COLLISION
                    )
                    
                    # Restore the joint states
                    for i, joint_idx in enumerate(self.leg_joints):
                        p.resetJointState(
                            self.robot_id, 
                            joint_idx, 
                            current_joint_positions[i], 
                            targetVelocity=current_joint_velocities[i]
                        )
                        
                        # Apply very low damping and friction
                        p.changeDynamics(
                            self.robot_id, 
                            joint_idx, 
                            lateralFriction=0.5,
                            jointDamping=0.01, 
                            maxJointVelocity=5.0
                        )
                    
                    # Mark the base as now unfixed
                    self.base_fixed = False
                    
                    # Let things settle
                    self.get_logger().info('Allowing robot to settle after unfixing base...')
                    for _ in range(100):
                        if self.shutdown_event.is_set():
                            return False
                        p.stepSimulation()
                        time.sleep(1.0/240.0)
            except Exception as e:
                self.get_logger().error(f"Error while unfixing base: {e}")
                return False
                
        self.get_logger().info('Moving to crouch position with gentle motions')
        
        # First check if robot is upside down, if so, reset it
        try:
            with self.simulation_lock:
                if not self.is_connected():
                    return False
                    
                pos, orn = p.getBasePositionAndOrientation(self.robot_id)
                euler = p.getEulerFromQuaternion(orn)
                if abs(euler[0]) > 0.5 or abs(euler[1]) > 0.5:  # More than ~30 degrees tilt
                    self.get_logger().warn("Robot tilt detected! Resetting position...")
                    p.resetBasePositionAndOrientation(
                        self.robot_id, 
                        [pos[0], pos[1], 0.25],  # Keep x,y but raise z
                        p.getQuaternionFromEuler([0, 0, euler[2]])  # Keep yaw, zero pitch and roll
                    )
                    self.pause_simulation(0.5)
        except Exception as e:
            self.get_logger().error(f"Error checking robot orientation: {e}")
            return False
        
        # Sequence of increasingly crouched positions for very smooth transition
        positions = [
            [0.0, -0.6, 0.0, -0.6, 0.0, -0.6, 0.0, -0.6],  # Slight crouch
            [0.0, -0.7, 0.0, -0.7, 0.0, -0.7, 0.0, -0.7],  # Medium crouch
            [0.0, -0.8, 0.0, -0.8, 0.0, -0.8, 0.0, -0.8],  # Lower crouch
            [0.0, -0.9, 0.0, -0.9, 0.0, -0.9, 0.0, -0.9]   # Full crouch
        ]
        
        # Move through each position with deliberate pauses
        for i, pos in enumerate(positions):
            if self.shutdown_event.is_set() or not self.is_connected():
                return False
                
            if not self.set_joint_angles(pos):
                return False
                
            self.get_logger().info(f'Crouch phase {i+1}/4')
            self.pause_simulation(0.5)  # Shorter pause for better responsiveness
        
        # Final pause after reaching crouch
        self.pause_simulation(0.5)
        return True
        
    def stand_position(self):
        """Move the robot to a standing position with careful transition"""
        # Check if 4 seconds have passed since spawn
        if self.shutdown_event.is_set() or not self.is_connected():
            return False
            
        if time.time() - self.spawn_time < 4.0:
            self.get_logger().info(f"Waiting for 4-second initialization period... ({time.time() - self.spawn_time:.1f}s)")
            return False
            
        # Make sure the base is unfixed first
        if self.base_fixed:
            if not self.crouch_position():  # This will handle unfixing the base
                return False
                
        self.get_logger().info('Moving to stand position with gentle motions')
        
        # Sequence of increasingly standing positions for very smooth transition
        positions = [
            [0.0, -0.8, 0.0, -0.8, 0.0, -0.8, 0.0, -0.8],  # Lower crouch
            [0.0, -0.75, 0.0, -0.75, 0.0, -0.75, 0.0, -0.75],  # Mid stand
            [0.0, -0.7, 0.0, -0.7, 0.0, -0.7, 0.0, -0.7]   # Full stand
        ]
        
        # Move through each position with deliberate pauses
        for i, pos in enumerate(positions):
            if self.shutdown_event.is_set() or not self.is_connected():
                return False
                
            if not self.set_joint_angles(pos):
                return False
                
            self.get_logger().info(f'Stand phase {i+1}/3')
            self.pause_simulation(0.5)  # Shorter pause for better responsiveness
        
        # Final pause after reaching stand
        self.pause_simulation(0.5)
        return True
            
    def trot_gait(self, continuous=True, max_steps=None):
        """Implement a trot gait with IMU-based stabilization and increased backward leg motion"""
        # Check if 4 seconds have passed since spawn
        if self.shutdown_event.is_set() or not self.is_connected():
            return False
            
        if time.time() - self.spawn_time < 4.0:
            self.get_logger().info(f"Waiting for 4-second initialization period... ({time.time() - self.spawn_time:.1f}s)")
            return False
            
        self.get_logger().info('Starting trot gait with IMU stabilization')
        
        # Base standing position
        base_positions = [
            0.0, -0.7,  # Front Left: leg, foot
            0.0, -0.7,  # Front Right: leg, foot
            0.0, -0.7,  # Rear Left: leg, foot
            0.0, -0.7   # Rear Right: leg, foot
        ]
        
        # Define step sequence for trot gait
        step_count = 0
        try:
            while rclpy.ok() and self.simulation_running:
                # Check if we need to stop
                if not self.currently_trotting or self.shutdown_event.is_set() or not self.is_connected():
                    break
                    
                step_count += 1
                self.get_logger().info(f'Trot step {step_count}')
                
                # If max_steps is set and we've reached it, break
                if max_steps is not None and step_count > max_steps:
                    break
                
                # Phase 1: Lift diagonal pair 1 (FL and RR) - more gently
                phase1 = base_positions.copy()
                phase1[1] = -0.85  # Front Left foot (less extreme lift)
                phase1[7] = -0.85  # Rear Right foot
                
                if not self.set_joint_angles(phase1):
                    break
                if not self.pause_simulation(0.3):  # Longer pause for smoother motion
                    break
                
                # Phase 2: Further lift and begin moving diagonal pair 1
                phase2 = phase1.copy()
                phase2[1] = -0.95  # Front Left foot lifted (less extreme than -1.0)
                phase2[7] = -0.95  # Rear Right foot lifted
                phase2[0] = -0.15  # Front left leg forward (reduced from -0.2)
                phase2[6] = 0.25   # Rear right leg backward (reduced from 0.35)
                
                if not self.set_joint_angles(phase2):
                    break
                if not self.pause_simulation(0.3):
                    break
                
                # Phase 3: Lower diagonal pair 1 - more gently
                phase3 = base_positions.copy()
                phase3[0] = -0.15   # Keep Front left leg forward
                phase3[6] = 0.25    # Keep Rear right leg backward
                
                if not self.set_joint_angles(phase3):
                    break
                if not self.pause_simulation(0.3):
                    break
                
                # Phase 4: Lift diagonal pair 2 (FR and RL) - more gently
                phase4 = base_positions.copy()
                phase4[0] = -0.15   # Keep Front left leg forward
                phase4[6] = 0.25    # Keep Rear right leg backward
                phase4[3] = -0.85   # Front Right foot (less extreme lift)
                phase4[5] = -0.85   # Rear Left foot
                
                if not self.set_joint_angles(phase4):
                    break
                if not self.pause_simulation(0.3):
                    break
                
                # Phase 5: Further lift and move diagonal pair 2 - more gently
                phase5 = phase4.copy()
                phase5[3] = -0.95   # Front Right foot lifted (less extreme)
                phase5[5] = -0.95   # Rear Left foot lifted
                phase5[2] = -0.15   # Front right leg forward (reduced from -0.2)
                phase5[4] = 0.25    # Rear left leg backward (reduced from 0.35)
                
                if not self.set_joint_angles(phase5):
                    break
                if not self.pause_simulation(0.3):
                    break
                
                # Phase 6: Lower diagonal pair 2 - more gently
                phase6 = base_positions.copy()
                phase6[0] = -0.08   # Front left leg slightly forward (reduced from -0.1)
                phase6[2] = -0.08   # Front right leg slightly forward
                phase6[4] = 0.12    # Rear left leg more backward
                phase6[6] = 0.12    # Rear right leg more backward
                
                if not self.set_joint_angles(phase6):
                    break
                if not self.pause_simulation(0.3):
                    break
                
                # Rest phase with slight backward stance
                rest_positions = base_positions.copy()
                rest_positions[4] = 0.04  # Rear left leg slightly backward
                rest_positions[6] = 0.04  # Rear right leg slightly backward
                
                if not self.set_joint_angles(rest_positions):
                    break
                if not self.pause_simulation(0.2):
                    break
                
                # Check robot orientation - if it's flipped, reset
                try:
                    with self.simulation_lock:
                        if not self.is_connected():
                            break
                            
                        pos, orn = p.getBasePositionAndOrientation(self.robot_id)
                        euler = p.getEulerFromQuaternion(orn)
                        if abs(euler[0]) > 0.7 or abs(euler[1]) > 0.7:  # Robot is tipped over
                            self.get_logger().warn("Robot tipped over! Resetting...")
                            p.resetBasePositionAndOrientation(
                                self.robot_id, 
                                [pos[0], pos[1], 0.25],
                                p.getQuaternionFromEuler([0, 0, euler[2]])
                            )
                            self.initialize_robot_pose()
                            break  # Exit the loop to start over
                except Exception as e:
                    self.get_logger().error(f"Error checking robot orientation: {e}")
                    break
                
                # Break the loop if not continuous
                if not continuous:
                    break
                    
        except KeyboardInterrupt:
            self.get_logger().info('Keyboard interrupt received. Stopping gait.')
        except Exception as e:
            self.get_logger().error(f"Error in trot_gait: {e}")
            
        # Reset to base standing position if possible
        if not self.shutdown_event.is_set() and self.is_connected():
            self.set_joint_angles(base_positions)
            self.pause_simulation(0.5)
        return True
        
    def toggle_stabilization(self):
        """Toggle IMU stabilization on/off"""
        self.stabilization_enabled = not self.stabilization_enabled
        self.get_logger().info(f"IMU stabilization: {'ENABLED' if self.stabilization_enabled else 'DISABLED'}")
                
    def pause_simulation(self, duration):
        """Pause for specific duration while continuing simulation steps"""
        start_time = time.time()
        while time.time() - start_time < duration:
            if not rclpy.ok() or self.shutdown_event.is_set() or not self.is_connected():
                return False
                
            # Process any callbacks
            rclpy.spin_once(self, timeout_sec=0)
            time.sleep(1./240.) # Match the simulation timestep
            
        return True
            
    def run_demo(self):
        """Run a demo sequence with the robot"""
        try:
            self.get_logger().info("Starting interactive demo with GUI controls...")
            
            # Wait for the 4-second initialization period
            while time.time() - self.spawn_time < 4.0:
                if self.shutdown_event.is_set() or not self.simulation_running:
                    return
                time.sleep(0.1)
            
            # Initial stabilization and unfixing the base
            if self.shutdown_event.is_set() or not self.simulation_running:
                return
                
            if not self.crouch_position():
                return
                
            # Now the robot is initialized and ready for commands
            self.initialization_complete = True
        except Exception as e:
            self.get_logger().error(f"Error in run_demo: {e}")
        
    def start_demo_thread(self):
        """Start the demo in a separate thread"""
        self.simulation_thread = Thread(target=self.run_demo)
        self.simulation_thread.daemon = True
        self.simulation_thread.start()
        
    def cleanup(self):
        """Clean up resources"""
        # Signal all threads to stop and wait
        self.simulation_running = False
        self.shutdown_event.set()
        time.sleep(0.2)  # Brief pause to let threads notice shutdown signal
        
        # Clean up temporary file if we created one
        if hasattr(self, 'urdf_path') and self.urdf_path and "temp" in self.urdf_path:
            try:
                os.unlink(self.urdf_path)
                self.get_logger().info(f"Temporary file {self.urdf_path} deleted")
            except:
                self.get_logger().warning(f"Could not delete temporary file {self.urdf_path}")
        
        # Disconnect from PyBullet within the lock to prevent race conditions
        with self.simulation_lock:
            try:
                if self.is_connected():
                    p.disconnect()
                    self.get_logger().info("Disconnected from PyBullet")
            except Exception as e:
                self.get_logger().debug(f"Error during disconnect: {e}")
        
def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = SpotMicroPyBulletROS2Bridge()
        
        try:
            # Start the demo in a separate thread
            node.start_demo_thread()
            
            # Keep the main thread for ROS 2 callbacks
            rclpy.spin(node)
        except KeyboardInterrupt:
            node.get_logger().info("User interrupted")
        finally:
            # Clean up resources
            node.cleanup()
            node.destroy_node()
    except Exception as e:
        print(f"Error initializing node: {e}")
    finally:
        try:
            rclpy.shutdown()
        except Exception:
            pass

if __name__ == '__main__':
    main()
