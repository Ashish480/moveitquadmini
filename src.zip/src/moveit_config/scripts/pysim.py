#!/usr/bin/env python3
import pybullet as p
import pybullet_data
import time
import numpy as np

# Initialize PyBullet
p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.setGravity(0, 0, -9.8)
p.loadURDF("plane.urdf")

# Robot dimensions
body_length = 0.3
body_width = 0.2
body_height = 0.1
leg_radius = 0.02
leg_length = 0.1
foot_length = 0.2
foot_width = 0.04
foot_height = 0.02

# Create a simple URDF file for a quadruped robot
quadruped_urdf = f"""<?xml version="1.0" ?>
<robot name="quadruped">
  <link name="base_link">
    <inertial>
      <mass value="1.0"/>
      <inertia ixx="0.01" ixy="0" ixz="0" iyy="0.01" iyz="0" izz="0.01"/>
    </inertial>
    <visual>
      <geometry>
        <box size="{body_length} {body_width} {body_height}"/>
      </geometry>
      <material name="orange">
        <color rgba="1.0 0.5 0.0 1.0"/>
      </material>
    </visual>
    <collision>
      <geometry>
        <box size="{body_length} {body_width} {body_height}"/>
      </geometry>
    </collision>
  </link>

  <!-- Front Left Leg -->
  <link name="front_left_leg">
    <inertial>
      <mass value="0.1"/>
      <inertia ixx="0.001" ixy="0" ixz="0" iyy="0.001" iyz="0" izz="0.001"/>
    </inertial>
    <visual>
      <geometry>
        <cylinder radius="{leg_radius}" length="{leg_length}"/>
      </geometry>
      <material name="gray">
        <color rgba="0.5 0.5 0.5 1.0"/>
      </material>
    </visual>
    <collision>
      <geometry>
        <cylinder radius="{leg_radius}" length="{leg_length}"/>
      </geometry>
    </collision>
  </link>

  <joint name="front_left_leg_joint" type="revolute">
    <parent link="base_link"/>
    <child link="front_left_leg"/>
    <origin rpy="0 0 0" xyz="{body_length/2-0.03} {body_width/2-0.03} 0"/>
    <axis xyz="0 1 0"/>
    <limit lower="-0.5" upper="0.5" effort="50" velocity="50"/>
  </joint>

  <link name="front_left_foot">
    <inertial>
      <mass value="0.1"/>
      <inertia ixx="0.001" ixy="0" ixz="0" iyy="0.001" iyz="0" izz="0.001"/>
    </inertial>
    <visual>
      <geometry>
        <box size="{foot_width} {foot_height} {foot_length}"/>
      </geometry>
      <material name="black">
        <color rgba="0.2 0.2 0.2 1.0"/>
      </material>
    </visual>
    <collision>
      <geometry>
        <box size="{foot_width} {foot_height} {foot_length}"/>
      </geometry>
    </collision>
  </link>

  <joint name="front_left_foot_joint" type="revolute">
    <parent link="front_left_leg"/>
    <child link="front_left_foot"/>
    <origin rpy="0 0 0" xyz="0 0 -{leg_length/2}"/>
    <axis xyz="0 1 0"/>
    <limit lower="-1.5" upper="1.5" effort="50" velocity="50"/>
  </joint>

  <!-- Front Right Leg -->
  <link name="front_right_leg">
    <inertial>
      <mass value="0.1"/>
      <inertia ixx="0.001" ixy="0" ixz="0" iyy="0.001" iyz="0" izz="0.001"/>
    </inertial>
    <visual>
      <geometry>
        <cylinder radius="{leg_radius}" length="{leg_length}"/>
      </geometry>
      <material name="gray">
        <color rgba="0.5 0.5 0.5 1.0"/>
      </material>
    </visual>
    <collision>
      <geometry>
        <cylinder radius="{leg_radius}" length="{leg_length}"/>
      </geometry>
    </collision>
  </link>

  <joint name="front_right_leg_joint" type="revolute">
    <parent link="base_link"/>
    <child link="front_right_leg"/>
    <origin rpy="0 0 0" xyz="{body_length/2-0.03} -{body_width/2-0.03} 0"/>
    <axis xyz="0 1 0"/>
    <limit lower="-0.5" upper="0.5" effort="50" velocity="50"/>
  </joint>

  <link name="front_right_foot">
    <inertial>
      <mass value="0.1"/>
      <inertia ixx="0.001" ixy="0" ixz="0" iyy="0.001" iyz="0" izz="0.001"/>
    </inertial>
    <visual>
      <geometry>
        <box size="{foot_width} {foot_height} {foot_length}"/>
      </geometry>
      <material name="black">
        <color rgba="0.2 0.2 0.2 1.0"/>
      </material>
    </visual>
    <collision>
      <geometry>
        <box size="{foot_width} {foot_height} {foot_length}"/>
      </geometry>
    </collision>
  </link>

  <joint name="front_right_foot_joint" type="revolute">
    <parent link="front_right_leg"/>
    <child link="front_right_foot"/>
    <origin rpy="0 0 0" xyz="0 0 -{leg_length/2}"/>
    <axis xyz="0 1 0"/>
    <limit lower="-1.5" upper="1.5" effort="50" velocity="50"/>
  </joint>

  <!-- Rear Left Leg -->
  <link name="rear_left_leg">
    <inertial>
      <mass value="0.1"/>
      <inertia ixx="0.001" ixy="0" ixz="0" iyy="0.001" iyz="0" izz="0.001"/>
    </inertial>
    <visual>
      <geometry>
        <cylinder radius="{leg_radius}" length="{leg_length}"/>
      </geometry>
      <material name="gray">
        <color rgba="0.5 0.5 0.5 1.0"/>
      </material>
    </visual>
    <collision>
      <geometry>
        <cylinder radius="{leg_radius}" length="{leg_length}"/>
      </geometry>
    </collision>
  </link>

  <joint name="rear_left_leg_joint" type="revolute">
    <parent link="base_link"/>
    <child link="rear_left_leg"/>
    <origin rpy="0 0 0" xyz="-{body_length/2-0.03} {body_width/2-0.03} 0"/>
    <axis xyz="0 1 0"/>
    <limit lower="-0.5" upper="0.5" effort="50" velocity="50"/>
  </joint>

  <link name="rear_left_foot">
    <inertial>
      <mass value="0.1"/>
      <inertia ixx="0.001" ixy="0" ixz="0" iyy="0.001" iyz="0" izz="0.001"/>
    </inertial>
    <visual>
      <geometry>
        <box size="{foot_width} {foot_height} {foot_length}"/>
      </geometry>
      <material name="black">
        <color rgba="0.2 0.2 0.2 1.0"/>
      </material>
    </visual>
    <collision>
      <geometry>
        <box size="{foot_width} {foot_height} {foot_length}"/>
      </geometry>
    </collision>
  </link>

  <joint name="rear_left_foot_joint" type="revolute">
    <parent link="rear_left_leg"/>
    <child link="rear_left_foot"/>
    <origin rpy="0 0 0" xyz="0 0 -{leg_length/2}"/>
    <axis xyz="0 1 0"/>
    <limit lower="-1.5" upper="1.5" effort="50" velocity="50"/>
  </joint>

  <!-- Rear Right Leg -->
  <link name="rear_right_leg">
    <inertial>
      <mass value="0.1"/>
      <inertia ixx="0.001" ixy="0" ixz="0" iyy="0.001" iyz="0" izz="0.001"/>
    </inertial>
    <visual>
      <geometry>
        <cylinder radius="{leg_radius}" length="{leg_length}"/>
      </geometry>
      <material name="gray">
        <color rgba="0.5 0.5 0.5 1.0"/>
      </material>
    </visual>
    <collision>
      <geometry>
        <cylinder radius="{leg_radius}" length="{leg_length}"/>
      </geometry>
    </collision>
  </link>

  <joint name="rear_right_leg_joint" type="revolute">
    <parent link="base_link"/>
    <child link="rear_right_leg"/>
    <origin rpy="0 0 0" xyz="-{body_length/2-0.03} -{body_width/2-0.03} 0"/>
    <axis xyz="0 1 0"/>
    <limit lower="-0.5" upper="0.5" effort="50" velocity="50"/>
  </joint>

  <link name="rear_right_foot">
    <inertial>
      <mass value="0.1"/>
      <inertia ixx="0.001" ixy="0" ixz="0" iyy="0.001" iyz="0" izz="0.001"/>
    </inertial>
    <visual>
      <geometry>
        <box size="{foot_width} {foot_height} {foot_length}"/>
      </geometry>
      <material name="black">
        <color rgba="0.2 0.2 0.2 1.0"/>
      </material>
    </visual>
    <collision>
      <geometry>
        <box size="{foot_width} {foot_height} {foot_length}"/>
      </geometry>
    </collision>
  </link>

  <joint name="rear_right_foot_joint" type="revolute">
    <parent link="rear_right_leg"/>
    <child link="rear_right_foot"/>
    <origin rpy="0 0 0" xyz="0 0 -{leg_length/2}"/>
    <axis xyz="0 1 0"/>
    <limit lower="-1.5" upper="1.5" effort="50" velocity="50"/>
  </joint>
</robot>
"""

# Save the URDF to a temporary file
import tempfile
with tempfile.NamedTemporaryFile(suffix='.urdf', delete=False) as f:
    f.write(quadruped_urdf.encode('utf-8'))
    urdf_path = f.name

# Load the URDF
robot_id = p.loadURDF(urdf_path, [0, 0, 0.3])

# Get joint information
num_joints = p.getNumJoints(robot_id)
print(f"Number of joints: {num_joints}")

# Joint mapping
joint_map = {
    'front_left_leg_joint': -1,
    'front_left_foot_joint': -1,
    'front_right_leg_joint': -1,
    'front_right_foot_joint': -1,
    'rear_left_leg_joint': -1,
    'rear_left_foot_joint': -1,
    'rear_right_leg_joint': -1,
    'rear_right_foot_joint': -1
}

# Get joint indices
for i in range(num_joints):
    joint_info = p.getJointInfo(robot_id, i)
    joint_name = joint_info[1].decode('utf-8')
    print(f"Joint {i}: {joint_name}")
    if joint_name in joint_map:
        joint_map[joint_name] = i

print("Joint mapping:", joint_map)

# Create ordered list of joints for convenience
leg_joints = [
    joint_map['front_left_leg_joint'],
    joint_map['front_left_foot_joint'],
    joint_map['front_right_leg_joint'],
    joint_map['front_right_foot_joint'],
    joint_map['rear_left_leg_joint'],
    joint_map['rear_left_foot_joint'],
    joint_map['rear_right_leg_joint'],
    joint_map['rear_right_foot_joint']
]

# Function to set joint angles
def set_joint_angles(angles):
    """Set angles for all joints"""
    for i, joint_index in enumerate(leg_joints):
        p.setJointMotorControl2(
            bodyUniqueId=robot_id,
            jointIndex=joint_index,
            controlMode=p.POSITION_CONTROL,
            targetPosition=angles[i],
            force=10
        )

# Stand position
def stand():
    """Set robot to standing position"""
    print("Standing up")
    # Order: FL leg, FL foot, FR leg, FR foot, RL leg, RL foot, RR leg, RR foot
    angles = [0.0, -0.7, 0.0, -0.7, 0.0, -0.7, 0.0, -0.7]
    set_joint_angles(angles)

# Crouch position
def crouch():
    """Set robot to crouching position"""
    print("Crouching")
    # Order: FL leg, FL foot, FR leg, FR foot, RL leg, RL foot, RR leg, RR foot
    angles = [0.0, -1.1, 0.0, -1.1, 0.0, -1.1, 0.0, -1.1]
    set_joint_angles(angles)

# Simple trot gait
def trot_gait(steps=5):
    """Implement a basic trot gait"""
    # Base standing position
    base_angles = [0.0, -0.7, 0.0, -0.7, 0.0, -0.7, 0.0, -0.7]
    
    for step in range(steps):
        print(f"Step {step+1}")
        
        # Phase 1: Lift diagonal pair 1 (FL and RR)
        phase1 = base_angles.copy()
        phase1[1] = -1.0  # Front Left foot
        phase1[7] = -1.0  # Rear Right foot
        set_joint_angles(phase1)
        for _ in range(20):
            p.stepSimulation()
            time.sleep(1./240.)
            
        # Phase 2: Move diagonal pair 1
        phase2 = phase1.copy()
        phase2[0] = -0.2  # Front Left leg
        phase2[6] = 0.2   # Rear Right leg
        set_joint_angles(phase2)
        for _ in range(20):
            p.stepSimulation()
            time.sleep(1./240.)
            
        # Phase 3: Lower diagonal pair 1
        phase3 = base_angles.copy()
        phase3[0] = -0.2  # Front Left leg
        phase3[6] = 0.2   # Rear Right leg
        set_joint_angles(phase3)
        for _ in range(20):
            p.stepSimulation() 
            time.sleep(1./240.)
            
        # Phase 4: Lift diagonal pair 2 (FR and RL)
        phase4 = base_angles.copy()
        phase4[3] = -1.0  # Front Right foot
        phase4[5] = -1.0  # Rear Left foot
        phase4[0] = -0.2  # Keep Front Left leg
        phase4[6] = 0.2   # Keep Rear Right leg
        set_joint_angles(phase4)
        for _ in range(20):
            p.stepSimulation()
            time.sleep(1./240.)
            
        # Phase 5: Move diagonal pair 2
        phase5 = phase4.copy()
        phase5[2] = -0.2  # Front Right leg
        phase5[4] = 0.2   # Rear Left leg
        set_joint_angles(phase5)
        for _ in range(20):
            p.stepSimulation()
            time.sleep(1./240.)
            
        # Phase 6: Lower diagonal pair 2
        phase6 = base_angles.copy()
        phase6[0] = -0.2  # Keep Front Left leg
        phase6[2] = -0.2  # Front Right leg
        phase6[4] = 0.2   # Rear Left leg
        phase6[6] = 0.2   # Rear Right leg
        set_joint_angles(phase6)
        for _ in range(20):
            p.stepSimulation()
            time.sleep(1./240.)
            
        # Reset to base position
        set_joint_angles(base_angles)
        for _ in range(10):
            p.stepSimulation()
            time.sleep(1./240.)

# Main simulation loop
print("Starting simulation...")

# Wait for robot to settle
for _ in range(100):
    p.stepSimulation()
    time.sleep(1./240.)

try:
    # First crouch
    crouch()
    for _ in range(100):
        p.stepSimulation()
        time.sleep(1./240.)
        
    # Then stand
    stand() 
    for _ in range(100):
        p.stepSimulation()
        time.sleep(1./240.)
        
    # Execute trot gait continuously until interrupted
    print("Starting trot gait... Press Ctrl+C to stop.")
    while True:
        trot_gait(1)
        
except KeyboardInterrupt:
    print("Simulation stopped by user")
    
finally:
    # Clean up temporary file
    import os
    try:
        os.unlink(urdf_path)
    except:
        pass
        
    p.disconnect()
    print("Disconnected from PyBullet")
