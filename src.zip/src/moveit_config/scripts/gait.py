#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from builtin_interfaces.msg import Duration
import time

class QuadrupedGaitController(Node):
    def __init__(self):
        super().__init__('quadruped_gait_controller')
        
        # Create an action client
        self.action_client = ActionClient(
            self, 
            FollowJointTrajectory, 
            '/legs_controller/follow_joint_trajectory'
        )
        
        # Use the CORRECT joint names from your robot
        self.joint_names = [
            'front_left_leg', 'front_left_foot',
            'front_right_leg', 'front_right_foot',
            'rear_left_leg', 'rear_left_foot',
            'rear_right_leg', 'rear_right_foot'
        ]
        
        self.get_logger().info('Waiting for action server...')
        self.action_client.wait_for_server()
        self.get_logger().info('Action server connected!')

    def send_joint_command(self, positions, duration_sec=1.0):
        """Send a command to move joints to specified positions"""
        goal_msg = FollowJointTrajectory.Goal()
        trajectory = JointTrajectory()
        trajectory.joint_names = self.joint_names
        
        point = JointTrajectoryPoint()
        point.positions = positions
        
        # Correctly create Duration object for ROS 2 Humble
        sec = int(duration_sec)
        nanosec = int((duration_sec - sec) * 1e9)
        duration = Duration()
        duration.sec = sec
        duration.nanosec = nanosec
        point.time_from_start = duration
        
        trajectory.points = [point]
        goal_msg.trajectory = trajectory
        
        self.get_logger().info(f'Sending positions: {positions}')
        self._send_goal_future = self.action_client.send_goal_async(goal_msg)
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info('Goal rejected')
            return
            
        self.get_logger().info('Goal accepted')
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)
        
    def get_result_callback(self, future):
        result = future.result().result
        self.get_logger().info('Action completed')
        
    def neutral_position(self):
        """Set robot to neutral position (all joints at 0)"""
        self.get_logger().info('Moving to neutral position')
        neutral = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        self.send_joint_command(neutral, 2.0)
        time.sleep(2.5)
        
    def crouch_position(self):
        """Move the robot to a crouched position"""
        self.get_logger().info('Moving to crouch position')
        
        # INVERTED foot values
        crouch_positions = [
            0.0, -1.1,  # Front Left: leg, foot
            0.0, -1.1,  # Front Right: leg, foot
            0.0, -1.1,  # Rear Left: leg, foot
            0.0, -1.1   # Rear Right: leg, foot
        ]
        
        self.send_joint_command(crouch_positions, 2.0)
        time.sleep(2.5)
        
    def stand_position(self):
        """Move the robot to a standing position"""
        self.get_logger().info('Moving to stand position')
        
        # INVERTED foot values
        stand_positions = [
            0.0, -0.7,  # Front Left: leg, foot
            0.0, -0.7,  # Front Right: leg, foot
            0.0, -0.7,  # Rear Left: leg, foot
            0.0, -0.7   # Rear Right: leg, foot
        ]
        
        self.send_joint_command(stand_positions, 2.0)
        time.sleep(2.5)
        
    def trot_gait(self, continuous=True):
        """Implement a basic trot gait where diagonal legs move together"""
        self.get_logger().info('Starting trot gait')
        
        # Base standing position - INVERTED foot values
        base_positions = [
            0.0, -0.7,  # Front Left: leg, foot
            0.0, -0.7,  # Front Right: leg, foot
            0.0, -0.7,  # Rear Left: leg, foot
            0.0, -0.7   # Rear Right: leg, foot
        ]
        
        # Define step sequence for trot gait
        step_count = 0
        try:
            while True:
                step_count += 1
                
                # Phase 1: Lift diagonal pair 1 (FL and RR)
                phase1_positions = base_positions.copy()
                # Modify FL foot (more bent to lift)
                phase1_positions[1] = -1.0  # Front Left foot
                # Modify RR foot (more bent to lift)
                phase1_positions[7] = -1.0  # Rear Right foot
                
                self.send_joint_command(phase1_positions, 0.3)
                time.sleep(0.35)
                
                # Phase 2: Move diagonal pair 1 forward and set down
                phase2_positions = base_positions.copy()
                # FL leg moved forward (negative value due to inversion)
                phase2_positions[0] = -0.2  # Swing front left leg forward
                # RR leg moved backward (positive value due to inversion)
                phase2_positions[6] = 0.2  # Swing rear right leg backward
                # Keep feet lifted
                phase2_positions[1] = -1.0  # Front Left foot
                phase2_positions[7] = -1.0  # Rear Right foot
                
                self.send_joint_command(phase2_positions, 0.3)
                time.sleep(0.35)
                
                # Phase 3: Set down diagonal pair 1
                phase3_positions = base_positions.copy()
                # Keep legs in moved position
                phase3_positions[0] = -0.2  # Front left leg forward
                phase3_positions[6] = 0.2  # Rear right leg backward
                # Set feet to normal standing position
                phase3_positions[1] = -0.7  # Front Left foot
                phase3_positions[7] = -0.7  # Rear Right foot
                
                self.send_joint_command(phase3_positions, 0.3)
                time.sleep(0.35)
                
                # Phase 4: Lift diagonal pair 2 (FR and RL)
                phase4_positions = base_positions.copy()
                # Keep legs 1 in moved position
                phase4_positions[0] = -0.2  # Front left leg forward
                phase4_positions[6] = 0.2  # Rear right leg backward
                # Modify FR foot (more bent to lift)
                phase4_positions[3] = -1.0  # Front Right foot
                # Modify RL foot (more bent to lift)
                phase4_positions[5] = -1.0  # Rear Left foot
                
                self.send_joint_command(phase4_positions, 0.3)
                time.sleep(0.35)
                
                # Phase 5: Move diagonal pair 2 forward and set down
                phase5_positions = base_positions.copy()
                # FR leg moved forward (negative value due to inversion)
                phase5_positions[2] = -0.2  # Swing front right leg forward
                # RL leg moved backward (positive value due to inversion)
                phase5_positions[4] = 0.2  # Swing rear left leg backward
                # Keep feet lifted
                phase5_positions[3] = -1.0  # Front Right foot
                phase5_positions[5] = -1.0  # Rear Left foot
                
                self.send_joint_command(phase5_positions, 0.3)
                time.sleep(0.35)
                
                # Phase 6: Set down diagonal pair 2 and reset pair 1
                phase6_positions = base_positions.copy()
                # Move pair 2
                phase6_positions[2] = -0.2  # Front right leg forward
                phase6_positions[4] = 0.2  # Rear left leg backward
                # Set pair 2 feet to normal standing position
                phase6_positions[3] = -0.7  # Front Right foot
                phase6_positions[5] = -0.7  # Rear Left foot
                
                self.send_joint_command(phase6_positions, 0.3)
                time.sleep(0.35)
                
                # Reset all legs to neutral stance
                self.send_joint_command(base_positions, 0.3)
                time.sleep(0.2)
                
                self.get_logger().info(f'Completed step {step_count}')
                
                # Break the loop if not continuous
                if not continuous:
                    break
                    
        except KeyboardInterrupt:
            self.get_logger().info('Keyboard interrupt received. Stopping gait.')
            
        # Reset to base standing position
        self.send_joint_command(base_positions, 1.0)
        time.sleep(1.2)
        
    def continuous_walking(self):
        """Start with crouch, then stand, then walk continuously"""
        try:
            # Step 1: Start in crouch position
            self.crouch_position()
            time.sleep(1.0)
            
            # Step 2: Stand up
            self.stand_position()
            time.sleep(1.0)
            
            # Step 3: Start continuous trot gait until interrupted
            self.trot_gait(continuous=True)
            
        except KeyboardInterrupt:
            self.get_logger().info('Keyboard interrupt received. Stopping robot.')
            
        # Safely return to crouch position
        self.crouch_position()
        time.sleep(1.0)

def main(args=None):
    rclpy.init(args=args)
    controller = QuadrupedGaitController()
    
    try:
        # Run the continuous walking sequence
        controller.continuous_walking()
        
    except KeyboardInterrupt:
        pass
        
    # Ensure the node gets destroyed properly
    rclpy.spin_once(controller, timeout_sec=1.0)
    controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
